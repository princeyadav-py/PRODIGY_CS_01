def caesar_cipher(text, shift, mode='encrypt'):
    result = ''
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            shift_val = shift if mode == 'encrypt' else -shift
            result += chr((ord(char) - base + shift_val) % 26 + base)
        else:
            result += char
    return result

def main():
    print("=== Caesar Cipher ===")
    message = input("Enter your message: ")
    while True:
        try:
            shift = int(input("Enter shift value (integer): "))
            break
        except ValueError:
            print("Shift must be an integer. Try again.")

    choice = input("Choose mode - (E)ncrypt or (D)ecrypt: ").strip().lower()
    if choice == 'e':
        result = caesar_cipher(message, shift, mode='encrypt')
        print("Encrypted message:", result)
    elif choice == 'd':
        result = caesar_cipher(message, shift, mode='decrypt')
        print("Decrypted message:", result)
    else:
        print("Invalid choice. Please enter E or D.")

if __name__ == "__main__":
    main()